
package assmain;

import java.util.ArrayList;


public class Student {

 private int studentId;
    private String studentName;
    private int studentAge;
    private String studentEmail;
    private String studentCourse;

   
    public Student(int id, String name, int age, String email, String course) {
        studentId = id;
        studentName = name;
        studentAge = age;
        studentEmail = email;
        studentCourse = course;
    }

    Student() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String email) {
        studentEmail = email;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    public void setStudentCourse(String course) {
        studentCourse = course;
    }

    // Save a new student
    public static void saveStudent(ArrayList<Student> students, int id, String name, int age, String email, String course) {
        // Check if age is valid
        if (age < 16) {
            System.out.println("Invalid student age. Age must be 16 or older.");
            return;
        }

        // Create a new student object and add it to the list
        students.add(new Student(id, name, age, email, course));
        System.out.println("Student details saved successfully.");
    }

    // Search for a student by ID
    public static Student searchStudent(ArrayList<Student> students, int id) {
        for (Student student : students) {
            if (student.getStudentId() == id) {
                return student;
            }
        }
        return null; // Student not found
    }

    // Delete a student by ID
    public static boolean deleteStudent(ArrayList<Student> students, int id) {
        Student studentToDelete = searchStudent(students, id);
        if (studentToDelete != null) {
            students.remove(studentToDelete);
            System.out.println("Student deleted successfully.");
            return true;
        }
        System.out.println("Student not found.");
        return false;
    }

    // Generate a student report
    public static void studentReport(ArrayList<Student> students) {
        System.out.println("Student Report:");
        for (Student student : students) {
            System.out.println(" ======================");
            System.out.println("ID: " + student.getStudentId() + 
                    "\n Name: " + student.getStudentName() +
                    "\n Age: " + student.getStudentAge() +
                    "\n Email: " + student.getStudentEmail() +
                    "\nCourse: " + student.getStudentCourse());
             System.out.println(" ======================");
        } 
        
    }
}    

