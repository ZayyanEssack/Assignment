import assmain.Student;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class StudentTest {
    private ArrayList<Student> students;

    @BeforeEach
    public void setUp() {
        students = new ArrayList<>();
    }

    @Test
    public void testSaveStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "John Doe", 20, "john@example.com", "Computer Science");

        // Check if the student was saved successfully
        assertEquals(1, students.size());
    }

    @Test
    public void testSearchStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "Alice Smith", 22, "alice@example.com", "Mathematics");

        // Search for an existing student
        Student foundStudent = Student.searchStudent(students, 1);
        assertNotNull(foundStudent);

        // Search for a non-existing student
        Student notFoundStudent = Student.searchStudent(students, 2);
        assertNull(notFoundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "Bob Johnson", 25, "bob@example.com", "Physics");

        // Delete an existing student
        boolean deleted = Student.deleteStudent(students, 1);
        assertTrue(deleted);

        // Attempt to delete a non-existing student
        boolean notDeleted = Student.deleteStudent(students, 2);
        assertFalse(notDeleted);
    }

    @Test
    public void testStudentReport() {
        // Save a few students
        Student.saveStudent(students, 1, "Mary Brown", 19, "mary@example.com", "Chemistry");
        Student.saveStudent(students, 2, "David Wilson", 21, "david@example.com", "Biology");
        Student.saveStudent(students, 3, "Sara Lee", 18, "sara@example.com", "Geology");

        // Generate a student report
        // Since generating a report involves printing to the console, you can test the report visually.
        // Here, we are just checking if the method runs without errors.
        Student.studentReport(students);
    }

    
}
