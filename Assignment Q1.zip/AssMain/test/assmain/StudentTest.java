package assmain;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

public class StudentTest {
    private ArrayList<Student> students;

    @BeforeEach
    public void setUp() {
        students = new ArrayList<>();
    }

    @Test
    public void testSaveStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "John Doe", 20, "john@example.com", "Computer Science");

        // Check if the student was saved successfully
        assertEquals(1, students.size());
    }

    @Test
    public void testSearchStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "Alice Smith", 22, "alice@example.com", "Mathematics");

        // Search for an existing student
        Student foundStudent = Student.searchStudent(students, 1);
        assertNotNull(foundStudent);
        assertEquals("Alice Smith", foundStudent.getStudentName());
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        // Search for a non-existing student
        Student notFoundStudent = Student.searchStudent(students, 2);
        assertNull(notFoundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Save a new student
        Student.saveStudent(students, 1, "Bob Johnson", 25, "bob@example.com", "Physics");

        // Delete an existing student
        boolean deleted = Student.deleteStudent(students, 1);
        assertTrue(deleted);
        assertEquals(0, students.size());
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Attempt to delete a non-existing student
        boolean notDeleted = Student.deleteStudent(students, 2);
        assertFalse(notDeleted);
        assertEquals(0, students.size());
    }

    @Test
    public void testStudentAge_StudentAgeValid() {
        // Save a new student with a valid age
        Student.saveStudent(students, 1, "Mary Brown", 18, "mary@example.com", "Chemistry");

        // Check that the student's age is valid
        Student student = students.get(0);
        assertEquals(18, student.getStudentAge());
    }

    @Test
    public void testStudentAge_StudentAgeInvalid() {
        // Attempt to save a student with an invalid age
        Student.saveStudent(students, 1, "David Wilson", 15, "david@example.com", "Biology");

        // Check that the student was not saved (invalid age)
        assertEquals(0, students.size());
    }

    @Test
    public void testStudentAge_StudentAgeInvalidCharacter() {
        // Attempt to save a student with an invalid character in age
        Student.saveStudent(students, 1, "Sara Lee", 17, "sara@example.com", "Geology");

        // Check that the student was not saved (invalid character)
        assertEquals(0, students.size());
    }

    
}

