
package assignment2;

import java.util.Scanner;



    
    public class InventoryApp {
    public static void main(String[] args) {
        NewClass iA =new NewClass () ;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the maximum number of products to manage: ");
        int capacity = scanner.nextInt();
        scanner.nextLine(); 

        InventoryManager manager = new InventoryManager(capacity);

        while (true) {
            System.out.println("\nOptions:");
            System.out.println("1. Add a Product");
            System.out.println("2. Display Inventory");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter price: R");
                    double price = scanner.nextDouble();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    scanner.nextLine(); 

                    Product product = new Product(name, price, quantity);
                    manager.addProduct(product);
                    break;
                case 2:
                    manager.displayInventory();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
    
    

