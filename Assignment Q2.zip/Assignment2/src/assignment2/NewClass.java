
package assignment2;
class Product {
    private String name;
    private double price;
    private int quantity;

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

class InventoryManager {
    private Product[] products;
    private int productCount;

    public InventoryManager(int capacity) {
        products = new Product[capacity];
        productCount = 0;
    }

    public void addProduct(Product product) {
        if (productCount < products.length) {
            products[productCount++] = product;
        } else {
            System.out.println("Inventory is full. Cannot add more products.");
        }
    }

    public void displayInventory() {
        System.out.println("Inventory Report:");
        System.out.println("=================================");
        for (int i = 0; i < productCount; i++) {
            Product product = products[i];
            System.out.println("Product Name: " + product.getName());
            System.out.println("Price: R" + product.getPrice());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("---------------------------------");
        }
        System.out.println("Total Products: " + productCount);
    }
}
public class NewClass {
    
}
