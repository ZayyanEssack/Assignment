import java.util.Scanner;

public class StudentManagementAppTest {
    public static void main(String[] args) {
        StudentManagementApp studentApp = new StudentManagementApp();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Test Case 1: Capture a new student");
        studentApp.saveStudent(scanner); // Test capturing a new student

        System.out.println("\nTest Case 2: Search for a student");
        studentApp.searchStudent(scanner); // Test searching for a student

        System.out.println("\nTest Case 3: Delete a student");
        studentApp.deleteStudent(scanner); // Test deleting a student

        System.out.println("\nTest Case 4: View student report");
        studentApp.studentReport(); // Test viewing student report

        System.out.println("\nTest Case 5: Exit student application");
        studentApp.exitStudentApplication(); // Test exiting the application
    }
}
