package assignment2;

import org.junit.Before;
import org.junit.jupiter.api.Test;

public class InventoryManagerTest {
    private InventoryManager manager;

    @Before
    public void setUp() {
        manager = new InventoryManager(5); // Create an inventory manager with a capacity of 5
    }

    @Test
    public void testAddProduct() {
        Product product1 = new Product("Product 1", 10.0, 5);
        Product product2 = new Product("Product 2", 15.0, 3);

        manager.addProduct(product1);
        manager.addProduct(product2);

        assertEquals(2, manager.getProductCount());
    }

    @Test
    public void testDisplayInventory() {
        Product product1 = new Product("Product 1", 10.0, 5);
        Product product2 = new Product("Product 2", 15.0, 3);

        manager.addProduct(product1);
        manager.addProduct(product2);

        String expectedOutput = """
                                Inventory Report:
                                =================================
                                Product Name: Product 1
                                Price: $10.0
                                Quantity: 5
                                ---------------------------------
                                Product Name: Product 2
                                Price: $15.0
                                Quantity: 3
                                ---------------------------------
                                Total Products: 2
                                """;

        assertEquals(expectedOutput, manager.getInventoryReport());
    }

    @Test
    public void testProductQuantity() {
        Product product1 = new Product("Product 1", 10.0, 5);
        manager.addProduct(product1);

        // Decrease the quantity
        manager.updateProductQuantity("Product 1", -2);

        assertEquals(3, product1.getQuantity());

        // Increase the quantity
        manager.updateProductQuantity("Product 1", 3);

        assertEquals(6, product1.getQuantity());
    }
}


